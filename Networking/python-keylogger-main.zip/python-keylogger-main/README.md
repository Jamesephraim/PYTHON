# Simple Python Keylogger with Pynput. Sending data to a server.
## This code DOES NOT promote or encourage any illegal activities! The content in this document is provided solely for educational purposes and to create awareness!

## This is a proof of concept and could be improved on in a lot of ways.

1. To run this code use `git clone https://github.com/davidbombal/python-keylogger.git`
2. Run the command `cd python-keylogger`
3. Create Virtual Environment in Windows. Using command `<python_path>\py -m venv keylogger_env`
4. Run command `keylogger_env\Scripts\activate`
5. Run the command `pip install -r requirements.txt` to install all the packages required in your virtual environment.
6. Run `py keylogger.py` this will run the program.

### To get the file to run on Windows 11 evading the antivirus I compiled the PyInstaller bootloader locally using Microsoft C/C++ compiler, and then used it to compile the code.
